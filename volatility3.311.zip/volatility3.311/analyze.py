#!/usr/bin/env python3


##
##---------------------------------------------------------------------------##
##
## This Python module belongs to the SF-SafeDump software package.
##
##
## Copyright (C) 2016-2023 by  Dr. Stephen Fedtke,  System Software
##
## Worldwide phone number: 00800-DRFEDTKE or 00800-37333853
##
##---------------------------------------------------------------------------##
##


version = '0.0' #   ./analyze <toolset> <dumpfile> <command> <args>...

import logging
import sys, os
import subprocess, re

toolsets = ['pypykatz']
tscmds = {'pypykatz': ['password']}
tstyps = {'password': ['SSP', 'Kerberos'] + ['ALL']}
tsstyps = {'SSP': [r'password ([^(]\S+)'], 'Kerberos': [r'Password: (\S+)']}

dumpfile = ''

def ana_pypykatz(tscmd, tstyp):

    basecmd = f"pypykatz lsa minidump {dumpfile}".split()
    p = subprocess.Popen(basecmd, stdout=subprocess.PIPE, text=True)
    csvrows = p.stdout
    typs = []
    in_typ = False
    for line in csvrows:
        line = line.rstrip('\n')
        #if re.search('==.*==', line):
        match = re.search('== (\w+) .*==', line)
        if match:
            in_typ = False
            typ = match.group(1)
            typs = list(set(typs + [typ]))
            if typ == tstyp or (typ in tstyps[cmd] and tstyp == 'ALL'):
                in_typ = True

        if in_typ:
            for patt in tsstyps[typ]:
                match = re.search(patt, line)
                if match:
                    pwd = match.group(1)
                    print(f'{typ}: {cmd} {pwd}')
            logger.info('%s, %s', typ, line)
    logger.info('all typs found: %s', typs)


# configure logging
if __name__ == '__main__':
    logging.basicConfig(level=getattr(logging, os.environ.get('LOGLEVEL', 'INFO').upper()), stream=sys.stderr, format='%(levelname)-8s %(message)s')
    logger = logging.getLogger(':')
    logger.info('analyze %s running with args %s', version, sys.argv[1:])
    dumpfile = sys.argv[1] if len(sys.argv) > 1 else ''
    ts = sys.argv[2] if len(sys.argv) > 2 else ''
    cmd = sys.argv[3] if len(sys.argv) > 3 else ''
    typ = sys.argv[4] if len(sys.argv) > 4 else ''
    if dumpfile == '' or not os.path.isfile(dumpfile):
        logger.error("no dumpfile '%s' given or missing", dumpfile)
        raise SystemExit(1)
    if cmd not in tscmds[ts]:
        logger.error("toolset '%s' command '%s' must be in %s", ts, cmd, tscmds[ts])
        raise SystemExit(1)
    if typ not in tstyps[cmd]:
        logger.error("toolset '%s' command '%s' type %s must be in %s", ts, cmd, typ, tstyps[cmd])
        raise SystemExit(1)
    eval(f'ana_{ts}(cmd, typ)')
